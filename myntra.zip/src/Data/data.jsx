import lip from '../Images/lip.webp';
import louis from '../Images/louis.webp';
import dennson from '../Images/dennson.webp';
import fablestreet from '../Images/fablestreet.webp';
import rareism from '../Images/rareism.webp';

 export let data =
[ 
{
  "userId": 1,
  "id": 1,
  "img":lip
},
{
  "userId": 1,
  "id": 2,
  "img":louis
},
{
  "userId": 1,
  "id": 3,
  "img":dennson
},
{
  "userId": 1,
  "id": 4,
  "img":fablestreet
},
{
  "userId": 1,
  "id": 5,
  "img":rareism
}
]